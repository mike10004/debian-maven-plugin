#!/bin/bash

java -cp /usr/share/example-single-project/classes org.example.dmpsingleproject.Program "$@"
